#include <stdio.h>

int main() {
   int ch;
    ch = 101/2 + 1;
   printf("%d\n", ch);
}